// Small Hours - Server Entry Point
// Starts the HTTP server with WebSocket support.

import express from 'express';
import http from 'http';
import fs from 'fs';
import manager from './session/manager.js';
import { setupRoutes } from './transport/http.js';
import { setupWebSocket } from './transport/ws-adapter.js';
import { prewarmCache } from './fetcher/cached-fetcher.js';

// Load .env if present (Node >=20.6 built-in; no dependency needed).
// Populates process.env with keys like GEMINI_API_KEY, DOMAIN, DISCORD_WEBHOOK_URL.
if (fs.existsSync('.env') && typeof process.loadEnvFile === 'function') {
  try { process.loadEnvFile('.env'); } catch { /* ignore malformed .env */ }
}

const PORT = parseInt(process.env.PORT, 10) || 3000;

const app = express();
app.set('trust proxy', 1);
app.use(express.json());

const server = http.createServer(app);

// Set up HTTP routes
setupRoutes(app, manager);

// Set up WebSocket handling
const { wss, broadcastToRoom, hasActiveSockets } = setupWebSocket(server, manager);

// Tell the manager how to check for active sockets (avoids cleaning up rooms with connected displays)
manager.hasActiveSockets = (code) => hasActiveSockets(code);

// Start listening (dual-stack IPv4+IPv6 by default; fall back to IPv4 if IPv6 is disabled)
const onListening = () => {
  console.log(`Small Hours server listening on port ${PORT}`);
  console.log(`  Local:   http://localhost:${PORT}`);
  console.log(`  Health:  http://localhost:${PORT}/health`);
};
server.once('error', (err) => {
  if (err && (err.code === 'EAFNOSUPPORT' || err.code === 'EADDRNOTAVAIL')) {
    server.listen(PORT, '0.0.0.0', onListening);
    return;
  }
  throw err;
});
server.listen(PORT, onListening);

prewarmCache().catch(err => console.warn('[prewarm] startup cache warm failed:', err.message));

// Graceful shutdown
function shutdown(signal) {
  console.log(`\n${signal} received. Shutting down gracefully...`);

  // Notify all rooms
  for (const [code] of manager.rooms) {
    broadcastToRoom(code, { type: 'SERVER_RESTARTING' });
  }

  // Close WebSocket server (terminates all connections)
  wss.close(() => {
    console.log('WebSocket server closed');
  });

  // Close HTTP server
  server.close(() => {
    console.log('HTTP server closed');
    manager.destroy();
    process.exit(0);
  });

  // Force exit after 5 seconds if graceful shutdown stalls
  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 5000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Crash resilience: a throw inside an async timer/WebSocket callback (e.g. the
// phase-timer game-end path) must not terminate the whole server and drop all
// rooms. Log and keep the process alive.
process.on('uncaughtException', (err) => {
  console.error('[fatal] uncaughtException:', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[fatal] unhandledRejection:', reason);
});
