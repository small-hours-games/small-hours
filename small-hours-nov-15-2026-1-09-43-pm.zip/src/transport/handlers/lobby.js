// Small Hours - Lobby message handlers

import { getView } from '../../engine/engine.js';
import { AVATAR_POOL } from '../../session/room.js';
import { stopRoomGame } from './game.js';

/**
 * Handle JOIN_LOBBY message — join as a new player or reconnect as existing player.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleJoinLobby(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom, sendToPlayer, playerSockets, graceTimers, getPlayerNames } = ctx;

  if (!msg.username) {
    send(ws, { type: 'ERROR', message: 'Username required' });
    return;
  }

  // Check for an existing player to reconnect. Reconnection requires the
  // unguessable reconnectToken, NOT the username — prevents admin/identity
  // hijack via username collision.
  let existingId = null;
  if (msg.reconnectToken) {
    for (const [id, p] of room.players) {
      if (p.reconnectToken === msg.reconnectToken) {
        existingId = id;
        break;
      }
    }
  }

  let playerId, avatar, reconnectToken;
  if (existingId) {
    // Reconnect existing player
    playerId = existingId;
    const player = room.players.get(existingId);
    avatar = player.avatar;
    reconnectToken = player.reconnectToken;
    player.connected = true;
    player.lastSeen = Date.now();
    if (meta.device) player.device = meta.device;
  } else {
    // New player
    ({ playerId, avatar, reconnectToken } = room.addPlayer(msg.username));
    const player = room.players.get(playerId);
    if (player && meta.device) player.device = meta.device;
  }

  meta.playerId = playerId;
  playerSockets.set(playerId, ws);

  // Cancel any pending grace timer
  if (graceTimers.has(playerId)) {
    clearTimeout(graceTimers.get(playerId));
    graceTimers.delete(playerId);
  }

  send(ws, { type: 'JOIN_OK', playerId, avatar, reconnectToken, avatarPool: AVATAR_POOL });
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });

  // If a game is running and this player hasn't surrendered, send current game state
  if (room.game && !room.surrendered?.has(playerId)) {
    const view = getView(room.game, playerId);
    const playerNames = getPlayerNames(room);
    const clock = ctx.timing ? ctx.timing(room) : {};
    sendToPlayer(playerId, { type: 'GAME_STATE', ...view, ...clock, gameType: room.gameType, playerNames });
  }
}

/**
 * Handle SET_READY message — mark a player as ready/not-ready.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleSetReady(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom } = ctx;

  if (!meta.playerId) {
    send(ws, { type: 'ERROR', message: 'Not joined yet' });
    return;
  }
  room.setReady(meta.playerId, msg.ready);
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });
}

/**
 * Handle SUGGEST_GAME message — player proposes a game type.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleSuggestGame(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom } = ctx;

  if (!meta.playerId) {
    send(ws, { type: 'ERROR', message: 'Not joined yet' });
    return;
  }
  if (!msg.gameType) {
    send(ws, { type: 'ERROR', message: 'gameType required' });
    return;
  }
  room.suggestGame(meta.playerId, msg.gameType);
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });
}

/**
 * Handle RETURN_TO_LOBBY message — admin ends the current game and returns to lobby.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleReturnToLobby(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom } = ctx;

  if (!meta.playerId) {
    send(ws, { type: 'ERROR', message: 'Not joined yet' });
    return;
  }

  const player = room.players.get(meta.playerId);
  if (!player || !player.isAdmin) {
    send(ws, { type: 'ERROR', message: 'Only admin can return to lobby' });
    return;
  }

  stopRoomGame(room, ctx);
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });
}

/**
 * Handle SET_AVATAR message — a player picks an avatar from the pool.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleSetAvatar(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom } = ctx;
  if (!meta.playerId) {
    send(ws, { type: 'ERROR', message: 'Not joined yet' });
    return;
  }
  const result = room.setAvatar(meta.playerId, String(msg.avatar || ''));
  if (!result.ok) {
    send(ws, { type: 'ERROR', message: result.error });
    return;
  }
  send(ws, { type: 'AVATAR_OK', avatar: result.avatar });
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });
}

/**
 * Handle SET_USERNAME message — a player updates their nickname.
 *
 * @param {import('ws')} ws
 * @param {object} meta
 * @param {object} room
 * @param {object} msg
 * @param {object} ctx
 */
export function handleSetUsername(ws, meta, room, msg, ctx) {
  const { send, broadcastToRoom } = ctx;
  if (!meta.playerId) {
    send(ws, { type: 'ERROR', message: 'Not joined yet' });
    return;
  }
  const result = room.setUsername(meta.playerId, String(msg.username || ''));
  if (!result.ok) {
    send(ws, { type: 'ERROR', message: result.error });
    return;
  }
  send(ws, { type: 'USERNAME_OK', username: result.username });
  broadcastToRoom(room.code, { type: 'LOBBY_UPDATE', state: room.getState() });
}
