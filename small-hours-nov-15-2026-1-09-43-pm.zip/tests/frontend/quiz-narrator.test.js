import { describe, it, expect, vi, afterEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
const source = readFileSync(new URL('../../games/quiz/client/lib/quiz-narrator.js', import.meta.url), 'utf8');
const settle = () => new Promise(resolve => setTimeout(resolve, 0));
const question = { phase: 'question', timeLeft: 15, question: { id: 'q1', text: 'Question?' } };
function setup(fetcher = vi.fn(async () => ({ ok: true, json: async () => ({ url: '/voice.wav' }) })), playClip = () => Promise.resolve(), clipDuration, extra = {}) {
  const clips = [];
  const browserSpeech = { speak: vi.fn(), cancel: vi.fn(), getVoices: () => [{ name: 'Daniel', lang: 'en-GB' }] };
  const context = { speechSynthesis: browserSpeech, SpeechSynthesisUtterance: function(text) { this.text = text; }, Date, fetch: fetcher, Audio: function(url) {
    const clip = { url, play: vi.fn(playClip), pause: vi.fn(), duration: clipDuration };
    clips.push(clip); return clip;
  } };
  Object.assign(context, extra);
  runInNewContext(source, context);
  const speaking = [];
  return { narrator: context.createQuizNarrator(on => speaking.push(on)), clips, fetcher, browserSpeech, speaking };
}
describe('TV game-show narration', () => {
  it('plays a prepared intro at once, without waiting for the network', async () => {
    const { narrator, clips, fetcher } = setup(undefined, undefined, 6.5);
    narrator.prepareIntro();
    narrator.prepareIntro();
    await settle();
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(clips).toHaveLength(1);
    narrator.sync({ phase: 'countdown', timeLeft: 5, gameType: 'quiz' });
    expect(clips[0].play).toHaveBeenCalledTimes(1); // same tick, no await
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(clips[0].playbackRate).toBeGreaterThan(1.15);
  });

  it('rewinds the prepared intro for the next game', async () => {
    const { narrator, clips } = setup();
    narrator.prepareIntro();
    await settle();
    narrator.sync({ phase: 'countdown', timeLeft: 5, gameType: 'quiz' });
    clips[0].currentTime = 3;
    narrator.stop();
    narrator.sync({ phase: 'countdown', timeLeft: 5, gameType: 'quiz' });
    expect(clips[0].currentTime).toBe(0);
    expect(clips[0].play).toHaveBeenCalledTimes(2);
  });

  it('still fetches the intro when preparing it failed', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce({ ok: false }).mockResolvedValue({ ok: true, json: async () => ({ url: '/voice.wav' }) });
    const { narrator, clips } = setup(fetcher);
    narrator.prepareIntro();
    await settle();
    narrator.sync({ phase: 'countdown', timeLeft: 5, gameType: 'quiz' });
    await settle();
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(clips[0].play).toHaveBeenCalled();
  });

  describe('fitting the intro and covering for slow audio', () => {
    afterEach(() => vi.useRealTimers());
    const intro = { phase: 'countdown', timeLeft: 5, gameType: 'quiz' };
    const never = () => new Promise(() => {});

    it('fits the intro to its real length, once that is known', async () => {
      const { narrator, clips } = setup();
      narrator.sync(intro);
      await settle();
      expect(clips[0].playbackRate).toBe(1);
      clips[0].duration = 7;
      clips[0].onloadedmetadata();
      expect(clips[0].playbackRate).toBeCloseTo(7 / 4.75, 1);
    });

    it('never slows a short intro or speeds a long one past 1.6', async () => {
      const short = setup(undefined, undefined, 2);
      short.narrator.sync(intro);
      await settle();
      expect(short.clips[0].playbackRate).toBe(1);
      const long = setup(undefined, undefined, 30);
      long.narrator.sync(intro);
      await settle();
      expect(long.clips[0].playbackRate).toBe(1.6);
    });

    it('lets the intro play to the end of the countdown without a cut-off timer', async () => {
      vi.useFakeTimers();
      const { narrator, clips } = setup(undefined, undefined, 5, { setTimeout, clearTimeout });
      narrator.sync(intro);
      await vi.advanceTimersByTimeAsync(0);
      await vi.advanceTimersByTimeAsync(6000);
      expect(clips[0].pause).not.toHaveBeenCalled();
    });

    it('reads with the browser voice when a clip is too slow, and ignores the late clip', async () => {
      vi.useFakeTimers();
      let answer;
      const fetcher = vi.fn(() => new Promise(resolve => { answer = resolve; }));
      const { narrator, clips, browserSpeech } = setup(fetcher, undefined, undefined, { setTimeout, clearTimeout });
      narrator.sync(question);
      await vi.advanceTimersByTimeAsync(2999);
      expect(browserSpeech.speak).not.toHaveBeenCalled();
      await vi.advanceTimersByTimeAsync(1);
      expect(browserSpeech.speak).toHaveBeenCalledTimes(1);
      answer({ ok: true, json: async () => ({ url: '/voice.wav' }) });
      await vi.advanceTimersByTimeAsync(0);
      expect(clips).toHaveLength(0);
    });

    it('does not start the browser voice when the clip arrives in time', async () => {
      vi.useFakeTimers();
      const { narrator, clips, browserSpeech } = setup(undefined, undefined, undefined, { setTimeout, clearTimeout });
      narrator.sync(question);
      await vi.advanceTimersByTimeAsync(0);
      await vi.advanceTimersByTimeAsync(5000);
      expect(clips).toHaveLength(1);
      expect(browserSpeech.speak).not.toHaveBeenCalled();
    });

    it('waits for the clip when the device has no browser voices', async () => {
      vi.useFakeTimers();
      let answer;
      const fetcher = vi.fn(() => new Promise(resolve => { answer = resolve; }));
      const { narrator, clips, browserSpeech } = setup(fetcher, undefined, undefined, { setTimeout, clearTimeout });
      browserSpeech.getVoices = () => [];
      narrator.sync(question);
      await vi.advanceTimersByTimeAsync(5000);
      answer({ ok: true, json: async () => ({ url: '/voice.wav' }) });
      await vi.advanceTimersByTimeAsync(0);
      expect(clips).toHaveLength(1);
      expect(browserSpeech.speak).not.toHaveBeenCalled();
    });

    it('does not read over a new phase after waiting', async () => {
      vi.useFakeTimers();
      const { narrator, browserSpeech } = setup(never, undefined, undefined, { setTimeout, clearTimeout });
      narrator.sync(question);
      narrator.sync({ phase: 'lobby' });
      await vi.advanceTimersByTimeAsync(5000);
      expect(browserSpeech.speak).not.toHaveBeenCalled();
    });
  });

  it('says when the voice speaks and when it has finished', async () => {
    const { narrator, clips, speaking } = setup();
    narrator.sync(question);
    await settle();
    expect(speaking.at(-1)).toBe(true);
    clips[0].onended();
    expect(speaking.at(-1)).toBe(false);
  });

  it('ends the speaking state when a new phase cuts the voice off', async () => {
    const { narrator, speaking } = setup();
    narrator.sync(question);
    await settle();
    narrator.sync({ phase: 'lobby' });
    expect(speaking.at(-1)).toBe(false);
  });

  it('does not count blocked autoplay as speaking until a gesture starts it', async () => {
    const { narrator, clips, speaking } = setup(undefined, () => Promise.reject(new Error('blocked')));
    narrator.sync(question);
    await settle();
    expect(speaking.at(-1)).toBe(false);
    clips[0].play = vi.fn(() => Promise.resolve());
    await narrator.retry();
    expect(speaking.at(-1)).toBe(true);
  });

  it('reports the browser voice too', async () => {
    const { narrator, browserSpeech, speaking } = setup(vi.fn(async () => ({ ok: false })));
    narrator.sync(question);
    await settle();
    const utterance = browserSpeech.speak.mock.calls[0][0];
    utterance.onstart();
    expect(speaking.at(-1)).toBe(true);
    utterance.onend();
    expect(speaking.at(-1)).toBe(false);
  });

  it('narrates countdown introduction and scales playbackRate to finish right as Question 1 starts', async () => {
    const { narrator, clips, fetcher } = setup(undefined, undefined, 7.5);
    narrator.sync({ phase: 'countdown', timeLeft: 5, gameType: 'quiz' });
    await settle();
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(JSON.parse(fetcher.mock.calls[0][1].body)).toEqual({
      text: 'Welcome to Smallhours Quiz Challenge, Here We go 3...2...1',
      style: 'game-show',
    });
    expect(clips[0].playbackRate).toBeGreaterThan(1.15);
    expect(clips[0].playbackRate).toBeLessThanOrEqual(1.6);
    // Transitioning to question 1 immediately stops the intro clip
    narrator.sync(question);
    expect(clips[0].pause).toHaveBeenCalled();
  });

  it('reads once per phase and cancels the question at reveal', async () => {
    const { narrator, clips, fetcher } = setup();
    narrator.sync(question);
    narrator.sync(question);
    await settle();
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(JSON.parse(fetcher.mock.calls[0][1].body)).toEqual({ text: 'Question?', style: 'game-show' });
    expect(clips[0].playbackRate).toBe(1);
    narrator.sync({ ...question, phase: 'reveal', correctAnswer: 'Paris' });
    expect(clips[0].pause).toHaveBeenCalled();
    await settle();
    expect(JSON.parse(fetcher.mock.calls[1][1].body).text).toBe('The answer is: Paris');
    narrator.stop();
    expect(clips[1].pause).toHaveBeenCalled();
  });
  it('drops late responses after a phase changes', async () => {
    let resolve;
    const { narrator, clips } = setup(() => new Promise(r => { resolve = r; }));
    narrator.sync(question);
    narrator.sync({ phase: 'between' });
    resolve({ ok: true, json: async () => ({ url: '/late.wav' }) });
    await settle();
    expect(clips).toHaveLength(0);
  });
  it('honors mute and leaves music questions free of narration', async () => {
    const { narrator, fetcher, clips } = setup();
    narrator.setMuted(true);
    narrator.sync(question);
    expect(fetcher).not.toHaveBeenCalled();
    narrator.setMuted(false);
    narrator.sync({ ...question, question: { ...question.question, id: 'q2', media: { preview: 'song' } } });
    expect(fetcher).not.toHaveBeenCalled();
    narrator.sync({ ...question, question: { ...question.question, id: 'q3' } });
    await settle();
    narrator.setMuted(true);
    expect(clips[0].pause).toHaveBeenCalled();
  });
});


it('uses the browser host voice when Gemini is unavailable, retries /api/tts on next phase, and honors mute', async () => {
  const { narrator, fetcher, browserSpeech } = setup(vi.fn(async () => ({ ok: false })));
  narrator.sync(question);
  await settle();
  expect(browserSpeech.speak).toHaveBeenCalledTimes(1);
  expect(browserSpeech.speak.mock.calls[0][0].text).toBe('Question?');
  expect(browserSpeech.speak.mock.calls[0][0].rate).toBe(1);
  expect(browserSpeech.speak.mock.calls[0][0].pitch).toBe(0.88);
  narrator.sync({ ...question, phase: 'reveal', correctAnswer: 'Mars' });
  expect(browserSpeech.cancel).toHaveBeenCalled();
  await settle();
  expect(browserSpeech.speak.mock.calls[1][0].text).toBe('The answer is: Mars');
  expect(fetcher).toHaveBeenCalledTimes(2);
  narrator.setMuted(true);
  expect(browserSpeech.cancel).toHaveBeenCalledTimes(2);
});
