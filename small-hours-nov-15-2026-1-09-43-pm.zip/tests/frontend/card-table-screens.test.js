// Phone + TV card-table screens for Gin Rummy and Palace, driven by real engine
// views. Functions are cut out of player.html / host.html and run with node:vm.
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { createTestGame, act, viewFor } from '../engine/game-harness.js';
import { getHostView } from '../../src/transport/host-view.js';
import ginRummy from '../../games/gin-rummy/rules.js';
import shithead from '../../games/shithead/rules.js';

const read = file => readFileSync(new URL('../../public/' + file, import.meta.url), 'utf8');
const KIT = read('js/table-cards.js');
const game = file => readFileSync(new URL('../../games/' + file, import.meta.url), 'utf8');
const PLAYER = read('js/table-cards-phone.js') + game('shithead/client/phone.js') + game('gin-rummy/client/phone.js');
const TV_KIT = read('js/table-cards-tv.js');
const TV_GAMES = game('shithead/client/tv.js') + '\n' + game('gin-rummy/client/tv.js');

function fn(source, name) {
  const start = source.indexOf('    function ' + name + '(');
  if (start === -1) throw new Error('missing ' + name);
  const end = source.indexOf('\n    }\n', start);
  return source.slice(start, end + 7);
}

function phoneContext(playerId) {
  const context = { state: { playerId, playerNames: { p1: 'Anna', p2: 'Bo', p3: 'Cy' } } };
  runInNewContext(KIT, context);
  const names = ['tcName', 'canPlayCard', 'shHasStacks', 'shZone', 'shActiveZoneCards', 'shCtaState', 'grOpponentId', 'grCtaState', 'grStatusText'];
  runInNewContext(names.map(n => fn(PLAYER, n)).join('\n'), context);
  return context;
}

function tvRender(fnName, view) {
  const content = { innerHTML: '' };
  const context = {
    state: { playerNames: { p1: 'Anna', p2: 'Bo', p3: 'Cy' } },
    audio: { play() {} },
    lastGrState: {},
    lastShState: {},
    document: { getElementById: () => content },
    escapeHtml: t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
    playerAvatarHtml: () => '',
    tcFitTv: () => {},
    SH: { registerGame() {}, aiPersona: () => null },
  };
  runInNewContext(KIT, context);
  const block = TV_KIT.slice(TV_KIT.indexOf('    // ===== Card table on the TV'));
  runInNewContext(block + '\n' + TV_GAMES, context);
  context[fnName]({ ...view, playerNames: context.state.playerNames });
  return content.innerHTML;
}

const SUIT_NAMES = { h: 'hearts', d: 'diamonds', c: 'clubs', s: 'spades' };
const LABELS = { 1: 'A', 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };
const ariaOf = c => 'aria-label="' + (LABELS[c.rank] || c.rank) + ' of ' + SUIT_NAMES[c.suit] + '"';

describe('a double tap never sends a card away', () => {
  const sent = [];
  function tapContext(extra) {
    const context = {
      renderGinRummyState() {}, renderShitheadState() {}, tcShake() {}, showToast() {},
      grDiscard: () => sent.push('discard'), playSelectedCards: () => sent.push('play'), shPlayFaceDown: () => sent.push('flip'),
      document: { getElementById: () => ({}) },
      ...extra,
    };
    runInNewContext(KIT, context);
    runInNewContext(['canPlayCard', 'shZone', 'shActiveZoneCards', 'shSwapSelect', 'shTapCard', 'grSelectCard'].map(n => fn(PLAYER, n)).join('\n'), context);
    return context;
  }

  it('Gin Rummy: the second tap deselects', () => {
    sent.length = 0;
    const ctx = tapContext({ state: { grSelectedCard: null, grLastMsg: { isMyTurn: true, phase: 'drawing', turnPhase: 'discard' } } });
    ctx.grSelectCard('c1');
    expect(ctx.state.grSelectedCard).toBe('c1');
    ctx.grSelectCard('c1');
    expect(ctx.state.grSelectedCard).toBe(null);
    expect(sent).toEqual([]);
  });

  const hand = [{ id: 'a', rank: 9, suit: 'h' }, { id: 'b', rank: 9, suit: 's' }];
  const palace = (msg, shStacked) => tapContext({ state: { shSelectedCards: [], shStacked, shLastMsg: { phase: 'play', isMyTurn: true, pileCount: 0, myHand: hand, myFaceUp: [], myFaceDownIds: [], ...msg } } });

  it('Palace: the second tap deselects a card and a stack', () => {
    sent.length = 0;
    for (const stacked of [false, true]) {
      const ctx = palace({}, stacked);
      ctx.shTapCard('a');
      expect(ctx.state.shSelectedCards.length).toBeGreaterThan(0);
      ctx.shTapCard('a');
      expect(ctx.state.shSelectedCards).toEqual([]);
    }
    expect(sent).toEqual([]);
  });

  it('Palace: the second tap does not flip a blind card', () => {
    sent.length = 0;
    const ctx = palace({ myHand: [], myFaceDownIds: ['x'] }, false);
    ctx.shTapCard('x');
    expect(ctx.state.shSelectedCards).toEqual(['x']);
    ctx.shTapCard('x');
    expect(ctx.state.shSelectedCards).toEqual([]);
    expect(sent).toEqual([]);
  });
});

describe('cards landing in the hand', () => {
  function tracker() {
    const context = { tcArrivals: {}, TC_MAX_ARRIVAL_FLIGHTS: 4 };
    runInNewContext(KIT, context);
    runInNewContext(fn(PLAYER, 'tcTrackArrivals'), context);
    return (hand, round) => context.tcTrackArrivals('gr', hand.map(id => ({ id })), round);
  }

  it('marks a drawn card, and only that card, until a card leaves the hand', () => {
    const track = tracker();
    track(['a', 'b'], 1);
    const drew = track(['a', 'b', 'c'], 1);
    expect([...drew.arrived]).toEqual(['c']);
    expect([...drew.t.fresh]).toEqual(['c']);
    expect([...drew.t.flying]).toEqual(['c']);
    expect([...track(['a', 'b', 'c'], 1).t.fresh]).toEqual(['c']);
    expect([...track(['a', 'c'], 1).t.fresh]).toEqual([]);
  });

  it('swaps the mark to the new card when a play and a draw arrive together', () => {
    const track = tracker();
    track(['a', 'b'], 'play');
    track(['a', 'b', 'c'], 'play');
    expect([...track(['a', 'c', 'd'], 'play').t.fresh]).toEqual(['d']);
  });

  it('treats a new deal as no arrival', () => {
    const track = tracker();
    track(['a', 'b'], 1);
    const dealt = track(['x', 'y'], 2);
    expect([...dealt.arrived]).toEqual([]);
    expect([...dealt.t.fresh]).toEqual([]);
  });
});

describe('Gin Rummy phone: next-move button follows the engine phases', () => {
  it('walks upcard → draw → discard', () => {
    let game = createTestGame(ginRummy, ['p1', 'p2']);
    const first = game.state.players[game.state.currentPlayerIndex];
    const ctx = phoneContext(first);
    const v1 = viewFor(game, first);
    expect(ctx.grCtaState(v1, null)).toMatchObject({ action: 'takeUpcard' });
    expect(ctx.grStatusText(v1)).toBe('Take the upcard or decline it');

    game = act(game, 'takeUpcard', first).game;
    const v2 = viewFor(game, first);
    expect(v2.turnPhase).toBe('discard');
    expect(ctx.grCtaState(v2, null)).toMatchObject({ disabled: true, label: 'Tap a card to discard' });
    expect(ctx.grCtaState(v2, v2.lastDrawnCardId)).toMatchObject({ disabled: true });
    const other = v2.myHand.find(c => c.id !== v2.lastDrawnCardId);
    expect(ctx.grCtaState(v2, other.id)).toMatchObject({ action: 'discard' });

    game = act(game, 'discard', first, { cardId: other.id }).game;
    const second = game.state.players.find(id => id !== first);
    const v3 = viewFor(game, second);
    expect(phoneContext(second).grCtaState(v3, null)).toMatchObject({ action: 'drawStock' });
    expect(ctx.grCtaState(viewFor(game, first), null)).toMatchObject({ disabled: true, label: 'Waiting for ' + (second === 'p1' ? 'Anna' : 'Bo') + '…' });
  });

  it('offers Next hand during scoring', () => {
    const ctx = phoneContext('p1');
    expect(ctx.grCtaState({ phase: 'scoring' }, null)).toMatchObject({ action: 'nextHand' });
  });
});

describe('Palace phone: next-move button', () => {
  it('confirms the swap, then plays a selection', () => {
    let game = createTestGame(shithead, ['p1', 'p2', 'p3']);
    const ctx = phoneContext('p1');
    expect(ctx.shCtaState(viewFor(game, 'p1'), [])).toMatchObject({ action: 'confirmSwap' });
    for (const p of ['p1', 'p2', 'p3']) game = act(game, 'confirmSwap', p).game;
    const current = game.state.players[game.state.currentPlayerIndex];
    const pctx = phoneContext(current);
    const view = viewFor(game, current);
    expect(view.phase).toBe('play');
    const card = view.myHand[0];
    expect(pctx.shCtaState(view, [card.id]).label).toMatch(/^Play /);
    expect(pctx.shCtaState(view, [])).toMatchObject({ disabled: true, label: 'Tap cards to play' });
  });

  it('shows the played card on the button: verb, count and card', () => {
    const ctx = phoneContext('p1');
    const hand = [{ id: 'a', rank: 6, suit: 'c' }, { id: 'b', rank: 6, suit: 'h' }, { id: 'c', rank: 6, suit: 'd' }];
    const view = { phase: 'play', isMyTurn: true, myHand: hand, pileTopRank: 5, pileCount: 2 };
    expect(ctx.shCtaState(view, ['a', 'b', 'c'])).toMatchObject({ verb: 'Play', count: 3, label: 'Play 3× 6', action: 'playCards' });
    expect(ctx.shCtaState(view, ['a']).card).toMatchObject({ id: 'a' });
  });

  it('stacks same ranks only once a hand no longer fits two rows of six', () => {
    const ctx = phoneContext('p1');
    const hand = n => Array.from({ length: n }, (_, i) => ({ id: 'x' + i, rank: 2 + (i % 11), suit: 'h' }));
    expect(ctx.shHasStacks(hand(12))).toBe(false);
    expect(ctx.shHasStacks(hand(13))).toBe(true);
    expect(ctx.shHasStacks(hand(11))).toBe(false);
  });

  it('asks to pick up the pile when nothing can be played', () => {
    const ctx = phoneContext('p1');
    const view = { phase: 'play', isMyTurn: true, myHand: [{ id: 'a', rank: 3, suit: 'h' }], pileTopRank: 13, pileCount: 5 };
    expect(ctx.shCtaState(view, [])).toMatchObject({ action: 'pickUpPile', label: 'Pick up the pile (5)' });
  });

  it('switches to blind face-down play at the end', () => {
    const ctx = phoneContext('p1');
    const view = { phase: 'play', isMyTurn: true, myHand: [], myFaceUp: [], myFaceDownIds: ['x1', 'x2'], pileCount: 0 };
    expect(ctx.shZone(view)).toBe('faceDown');
    expect(ctx.shCtaState(view, ['x1'])).toMatchObject({ action: 'playFaceDown' });
  });
});

describe('TV card tables never show private hands', () => {
  it('Gin Rummy: table and seats only, no hand cards', () => {
    const game = createTestGame(ginRummy, ['p1', 'p2']);
    const html = tvRender('renderGinRummy', getHostView(game, 'p1'));
    expect(html).toContain('tc-tv');
    expect(html).toContain('Stock');
    for (const pid of ['p1', 'p2']) {
      for (const c of game.state.hands[pid]) expect(html).not.toContain(ariaOf(c));
    }
    expect(html).toContain(ariaOf(game.state.discard[game.state.discard.length - 1]));
  });

  it('Gin Rummy: reveals both players melds once the hand is scored', () => {
    let game = createTestGame(ginRummy, ['p1', 'p2']);
    const first = game.state.players[game.state.currentPlayerIndex];
    game = { ...game, state: { ...game.state, phase: 'drawing', turnPhase: 'discard' } };
    // Give the current player a knockable hand: A-2-3-4 of hearts, 5-5-5, 9-9-9 (+ a 10 to keep 11 cards)
    const hand = [1, 2, 3, 4].map(r => ({ id: r + 'h_k', rank: r, suit: 'h' }))
      .concat(['s', 'c', 'd'].map(s => ({ id: '5' + s + '_k', rank: 5, suit: s })))
      .concat(['s', 'c', 'd'].map(s => ({ id: '9' + s + '_k', rank: 9, suit: s })))
      .concat([{ id: '10s_k', rank: 10, suit: 's' }]);
    game = { ...game, state: { ...game.state, hands: { ...game.state.hands, [first]: hand } } };
    game = act(game, 'knock', first).game;
    expect(game.state.phase).toBe('scoring');
    const html = tvRender('renderGinRummy', getHostView(game, 'p1'));
    expect(html).toContain('(knocked)');
    expect(html).toContain('tc-meld-run');
    expect(html).toContain('tc-meld-set');
  });

  it('Palace: face-up cards are public, hands are not', () => {
    let game = createTestGame(shithead, ['p1', 'p2', 'p3']);
    for (const p of ['p1', 'p2', 'p3']) game = act(game, 'confirmSwap', p).game;
    const html = tvRender('renderShithead', getHostView(game, 'p1'));
    for (const pid of ['p1', 'p2', 'p3']) {
      for (const c of game.state.hands[pid]) expect(html).not.toContain(ariaOf(c));
      for (const c of game.state.faceUp[pid]) expect(html).toContain(ariaOf(c));
      for (const c of game.state.faceDown[pid]) expect(html).not.toContain(ariaOf(c));
    }
    expect(html).toContain('Draw deck');
    expect(html).toContain("'s turn");
  });
});

describe('TV card tables escape hostile values', () => {
  const evil = '<img src=x onerror=alert(1)>';
  it('Gin Rummy: numeric fields cannot inject markup', () => {
    const html = tvRender('renderGinRummy', {
      phase: 'drawing', turnPhase: 'draw', currentPlayer: 'p1', handNumber: evil,
      cumulative: { p1: evil, p2: 3 }, boxes: { p1: evil, p2: 0 }, playerCardCounts: { p1: evil, p2: 10 },
      stockCount: evil, discardCount: evil, discardTop: null, events: [],
    });
    expect(html).not.toContain('<img');
  });

  it('Palace: numeric fields cannot inject markup', () => {
    const html = tvRender('renderShithead', {
      phase: 'play', currentPlayer: 'p1', drawPileCount: evil, pileCount: evil, pileTopRank: 5,
      players: [{ playerId: 'p1', handCount: evil, faceUp: [], faceDownCount: evil, isOut: false }],
      finishOrder: [],
    });
    expect(html).not.toContain('<img');
  });
});

describe('Gin Rummy move log formatting and TV rendering', () => {
  it('formats Gin Rummy events in renderMoveLog with card chips or card backs', () => {
    const ctx = phoneContext('p1');
    const card = { id: '7h_0', rank: 7, suit: 'h' };
    const log = [
      { seq: 1, kind: 'gr-decline-upcard', by: 'p1', cards: [] },
      { seq: 2, kind: 'gr-draw-stock', by: 'p2', cards: [] },
      { seq: 3, kind: 'gr-discard', by: 'p2', cards: [card] },
      { seq: 4, kind: 'gr-draw-discard', by: 'p1', cards: [card] },
    ];
    const html = ctx.renderMoveLog(log, { name: id => (id === 'p1' ? 'Anna' : 'Bo'), max: 4 });
    expect(html).toContain('Bo discarded 7♥');
    expect(html).toContain('Anna took 7♥ from discard');
    expect(html).toContain('Bo drew from stock');
    expect(html).toContain('tc-chip-back');
    expect(html).toContain('Anna declined the upcard');
  });

  it('renders the move log on the Gin Rummy TV table', () => {
    let game = createTestGame(ginRummy, ['p1', 'p2']);
    const first = game.state.players[game.state.currentPlayerIndex];
    game = act(game, 'takeUpcard', first).game;
    const html = tvRender('renderGinRummy', getHostView(game, 'p1'));
    expect(html).toContain('tc-log');
    expect(html).toContain('took the upcard');
    expect(html).toContain('tc-well-drawn');
  });

  it('shows opponent draw source in phone status text and knock banner on TV', () => {
    const ctx = phoneContext('p1');
    const card = { id: '12h_0', rank: 12, suit: 'h' };
    expect(ctx.grStatusText({
      phase: 'drawing', turnPhase: 'discard', isMyTurn: false,
      cumulative: { p1: 0, p2: 0 },
      lastEvent: { seq: 4, kind: 'gr-draw-stock', by: 'p2', cards: [] },
    })).toBe('Bo drew from stock — discarding');
    expect(ctx.grStatusText({
      phase: 'drawing', turnPhase: 'discard', isMyTurn: false,
      cumulative: { p1: 0, p2: 0 },
      lastEvent: { seq: 5, kind: 'gr-draw-discard', by: 'p2', cards: [card] },
    })).toBe('Bo took Q♥ from discard — discarding');

    const knockHtml = tvRender('renderGinRummy', {
      phase: 'scoring', knocker: 'p2', handNumber: 1,
      cumulative: { p1: 0, p2: 20 }, boxes: { p1: 0, p2: 1 },
      playerCardCounts: { p1: 10, p2: 10 },
      handResult: { type: 'knock', winner: 'p2', points: 20 },
      knockerMelds: [], knockerDeadwood: [], opponentMelds: [], opponentDeadwood: [], opponentLayoffs: [],
    });
    expect(knockHtml).toContain('tc-knock-banner');
    expect(knockHtml).toContain('Bo knocked!');
  });
});

describe('Palace visibility on TV', () => {
  it('highlights pile well on pickup and burn and shows finished banner', () => {
    const pickupHtml = tvRender('renderShithead', {
      phase: 'play', currentPlayer: 'p2', drawPileCount: 10, pileCount: 0, pileTopRank: null,
      players: [
        { playerId: 'p1', handCount: 4, faceUp: [], faceDownCount: 3, isOut: false },
        { playerId: 'p2', handCount: 3, faceUp: [], faceDownCount: 3, isOut: false },
      ],
      finishOrder: [],
      lastEvent: { seq: 11, kind: 'pickup', by: 'p1', count: 4 },
    });
    expect(pickupHtml).toContain('tc-well-drawn');
    expect(pickupHtml).toContain('picked up 4');

    const burnHtml = tvRender('renderShithead', {
      phase: 'play', currentPlayer: 'p2', drawPileCount: 10, pileCount: 0, pileTopRank: null,
      players: [
        { playerId: 'p1', handCount: 3, faceUp: [], faceDownCount: 3, isOut: false },
        { playerId: 'p2', handCount: 3, faceUp: [], faceDownCount: 3, isOut: false },
      ],
      finishOrder: [],
      lastEvent: { seq: 12, kind: 'burn', by: 'p2', cards: [{ id: '10h_0', rank: 10, suit: 'h' }] },
    });
    expect(burnHtml).toContain('sh-burned');
    expect(burnHtml).toContain('Bo burned!');

    const finishHtml = tvRender('renderShithead', {
      phase: 'finished', currentPlayer: null, drawPileCount: 0, pileCount: 0, pileTopRank: null,
      players: [
        { playerId: 'p1', handCount: 0, faceUp: [], faceDownCount: 0, isOut: true },
        { playerId: 'p2', handCount: 2, faceUp: [], faceDownCount: 1, isOut: false },
      ],
      finishOrder: ['p1'],
      loser: 'p2',
    });
    expect(finishHtml).toContain('tc-result-pop');
    expect(finishHtml).toContain('tc-knock-banner');
    expect(finishHtml).toContain('Bo keeps the palace!');
  });
});

describe('Card selection visuals, turn glow, and Gin Rummy hand timer policy', () => {
  it('styles selected cards raised with a red border and turn glow with light green', () => {
    const css = readFileSync(new URL('../../public/css/table-cards.css', import.meta.url), 'utf8');
    expect(css).toContain('translateY(-14px)');
    expect(css).toContain('#ef4444');
    expect(css).toContain('.tc-screen.tc-my-turn-glow');
    expect(css).toContain('#4ade80');
  });

  it('supports No limit, 20s, and 10s between-hands timer in Gin Rummy', () => {
    let game = createTestGame(ginRummy, ['p1', 'p2'], { handTimeLimitSec: 20 });
    expect(game.state.phaseDurations).toEqual({ scoring: 20000 });
    game = { ...game, state: { ...game.state, phase: 'scoring' } };
    game = act(game, 'timerExpired', 'p1', { phase: 'scoring' }).game;
    expect(game.state.handNumber).toBe(2);
    expect(game.state.phase).toBe('first_turn');

    const noLimit = createTestGame(ginRummy, ['p1', 'p2'], { handTimeLimitSec: 0 });
    expect(noLimit.state.phaseDurations).toBeNull();
  });
});
