# Small Hours Live Tables Admin Dashboard (`/dashboard`)

A dedicated, OIDC-authenticated operations console at `/dashboard` that lets Small Hours administrators monitor active game tables in real time, inspect connected players, bots, and TV hosts along with parsed phone/device details, and perform safe moderation actions.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product and UX choices were confirmed during clarification and govern this plan:

- **Confirmed Decision 1 — Live Updates**: Auto-refreshing live feed polling every few seconds (3s cadence) with a pause/resume toggle and immediate manual refresh trigger.
- **Confirmed Decision 2 — Moderation Actions**: Read-only telemetry plus targeted admin actions to **Kick Player** from a table or **Close Table** entirely (with confirmation prompts).
- **Confirmed Decision 3 — Device & Phone Details**: Parsed device, OS, and browser summary (e.g., `iPhone · iOS 18 · Safari`, `Android · Pixel · Chrome`, `Android TV`) alongside an expandable toggle to inspect the raw `User-Agent` string.
- **Confirmed Decision 4 — Portal Integration**: A unified, shared top navigation bar across both `/dashboard` (Live Tables) and `/admin` (API Keys & Games) so admins can switch views seamlessly within one authenticated session.

---

## 1. Overview & Core Concept

- **What It Does**: Provides a real-time operational overview of every active Small Hours room ("table")—showing total ongoing tables, active games vs. lobbies, connected human players, AI bot seats, TV host displays, and observers, along with each participant's device/phone profile and connection state.
- **Target Audience / Persona**: Small Hours administrators and party hosts running or troubleshooting live multiplayer sessions across phones and TVs.
- **Key Value**: Gives admins instant visibility into who is playing what, which phone or TV client each participant is using (crucial for debugging mobile/WebView quirks), and the ability to clear stuck tables or remove disruptive players without restarting the server.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **OIDC Authentication & Redirect**:
   - Unauthenticated visits to `/dashboard` redirect through the existing OIDC Authorization Code + PKCE flow (and support the local `ADMIN_DEV_TOKEN` dev bypass when OIDC is unconfigured, showing the same OIDC setup notice if unconfigured).
   - After signing in at the identity provider, the callback returns the user directly back to `/dashboard` (preserving the original destination rather than forcing a detour to `/admin`).
2. **Live Overview & Filtering**:
   - On load, `/dashboard` renders a clean 4-metric summary strip (Ongoing Tables, Active Games, Connected Players, TV Hosts Online) using tabular numerals, followed by a filter toolbar (text search by room code, player name, or game title, plus segmented status filters: `All`, `In Game`, `Lobby`).
   - A 3-second auto-refresh loop keeps counts, round/game status, and player connection states fresh without page flicker, with a pause/resume toggle and an explicit **Refresh** action.
3. **Inspecting Tables, Players & Phones**:
   - Each ongoing table is presented as a single-elevation flat panel showing the room code, current game or lobby status, elapsed duration / idle age, language, TV host connection summary, and a compact participant roster table.
   - Each player row displays avatar + nickname, admin/connection state as clean unboxed text (`Host · Connected` or `Disconnected`), session score, and a parsed device/OS/browser summary (e.g., `iPhone · iOS 18.1 · Safari`).
   - Clicking a device entry expands an inline raw `User-Agent` inspection drawer/row so admins can verify exact OS versions, WebView builds, or browser engines.
   - Connected TV host displays and observers on each table are listed in a dedicated compact sub-strip with their parsed TV/browser device details and raw `User-Agent` toggle.
4. **Moderation Actions (Kick Player / Close Table)**:
   - Each player row offers a **Kick** button; each table header offers a **Close Table** button.
   - Clicking either triggers a crisp inline confirmation dialog (or modal) naming the target player/table, then calls the authenticated admin endpoint, immediately disconnects the targeted socket(s), updates room state, and refreshes the table list.

### Visual Identity & Theme

- **Aesthetic Direction**: High-craft dark operational console aligned with the existing Small Hours `/admin` dark slate aesthetic, refined for dense scannability and zero visual clutter.
- **Color Palette & Mood**:
  - *60% Dominant Neutral Canvas*: Deep slate `#020617` (`bg-slate-950`).
  - *30% Structural Surfaces*: Charcoal slate `#0F172A` (`bg-slate-900`) panels with crisp 1px hairline borders (`border-slate-800`) and zero nested card shadows.
  - *10% Accent & Semantic Budget*: Sky blue (`#0284C7` / `text-sky-400`) for primary interactive focus and active nav links; emerald (`#16A34A` / `text-emerald-400`) paired with explicit text for active games/connected clients; amber (`#D97706`) for grace-period disconnects; crimson (`#DC2626`) reserved strictly for destructive Kick/Close actions.
- **Typography & Hierarchy**:
  - *Display & UI*: `Plus Jakarta Sans` (consistent with Small Hours brand typography) for headings, navigation, and labels.
  - *Telemetry & Identifiers*: `JetBrains Mono` / monospace with `font-variant-numeric: tabular-nums` for room codes, counts, scores, durations, and raw `User-Agent` strings.
- **Shared Top Bar Contract**:
  - Both `/dashboard` and `/admin` use an identical single-row, three-zone header (`gap-8`):
    1. *Brand Zone*: Single-line `Small Hours Admin` wordmark.
    2. *Navigation Zone*: Clean text links (`Live Tables` → `/dashboard`, `API & Games` → `/admin`, `Home` → `/`) with subtle active underline/color—no filled capsule pills.
    3. *Action Zone*: Signed-in admin identity label (plain text) and a single `Sign out` button.
- **Zero-Pill & Anti-Slop Discipline**:
  - Static metadata (device OS, browser, connection state, timestamps, bot markers) renders as quiet unboxed text with `·` separators rather than rounded pill capsules.
  - No pulsing decorative status dots, no thick left accent borders, no nested cards-within-cards, and complete empty/loading/error states (including a clear empty state when zero tables are currently active).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — OIDC Return-To Continuity (`returnTo` in OIDC transaction)**
  - *Chosen Approach*: Keep `/admin/callback` as the single registered OIDC `redirect_uri`, while allowing `/admin/login?next=/dashboard` (or automatic redirect from `/dashboard`) to store a validated relative `returnTo` path inside the signed HMAC `sh_oidc_tx` cookie.
  - *Why*: External OIDC providers (Authentik, Keycloak, Google, Auth0) enforce exact `redirect_uri` whitelists. Reusing `/admin/callback` guarantees zero breaking changes to existing `.env` and IdP client configurations while landing admins cleanly on `/dashboard`.
  - *Alternatives Considered*: Registering a second `/dashboard/callback` redirect URI—rejected because it would break existing OIDC deployments until admins updated their identity provider settings.

- **Decision 2 — Server-Side Device & Phone Capture at WebSocket Upgrade**
  - *Chosen Approach*: Capture the HTTP `User-Agent` header (and optional client hints / role metadata) during WebSocket `connection` in the transport layer, store it per-connection and per-player in the room/socket metadata, and parse it server-side with a lightweight, dependency-free User-Agent classifier into `{ deviceType, brandOrModel, os, browser, isAndroidTv, raw }`.
  - *Why*: Capturing `User-Agent` on the WebSocket upgrade works automatically for every existing phone, desktop browser, and the Android TV WebView app (`MainActivity.java`) without needing client protocol changes, and keeps parsing deterministic and testable with zero extra npm dependencies.
  - *Alternatives Considered*: Installing a heavy third-party UA parser package or requiring every client page to send navigator payloads—rejected to keep dependencies minimal and support legacy/TV clients immediately.

- **Decision 3 — Auto-Refresh Polling vs. Admin WebSocket Push**
  - *Chosen Approach*: Authenticated JSON endpoint polled every 3 seconds when the tab is visible (`document.visibilityState === 'visible'`), paired with a pause/resume toggle and immediate refresh after moderation actions.
  - *Why*: Matches the confirmed requirement, avoids maintaining an extra authenticated WebSocket upgrade pipeline and subscription fan-out, works cleanly behind reverse proxies, and imposes negligible load for in-memory room counts.
  - *Alternatives Considered*: Dedicated admin WebSocket channel—unnecessary complexity for an ops dashboard with a 3-second refresh target.

- **Decision 4 — Safe Moderation Plumbing Between Transport & Session**
  - *Chosen Approach*: Expose clean room-control hooks (`kickPlayer(code, playerId)` and `closeRoom(code)`) wired from the WebSocket adapter so admin HTTP routes can cleanly cancel active phase/bot/countdown/grace timers, notify affected sockets (`KICKED` / `ROOM_CLOSED` or error + close), remove the player or room, and broadcast updated `LOBBY_UPDATE` to remaining clients.
  - *Why*: Simply deleting from `manager.rooms` without clearing `ws-adapter` timers and sockets would leave orphaned phase timers or zombie TV connections.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### System Architecture & Data Flow

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ Browser Clients (Phones / Browsers / Android TV)                             │
│   └─ WS Upgrade (/ws/player/:code, /ws/host/:code, /ws/observer/:code)       │
│        │  carries HTTP User-Agent header                                     │
└────────┼─────────────────────────────────────────────────────────────────────┘
         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│ WebSocket Adapter & Session Layer                                            │
│   ├─ Records device profile per socket & player (parsed + raw User-Agent)    │
│   ├─ Tracks roomSockets (hosts, players, observers) & active timers          │
│   └─ Exposes admin control hooks: kickPlayer(), closeRoom(), listTables()    │
└────────┬─────────────────────────────────────────────────▲───────────────────┘
         │ reads live snapshot                             │ moderation action
         ▼                                                 │
┌──────────────────────────────────────────────────────────────────────────────┐
│ Admin & OIDC Auth Layer (/admin/* & /dashboard)                              │
│   ├─ GET  /dashboard               ──▶ Session check ──▶ /admin/login?next=  │
│   ├─ GET  /admin/api/tables        ──▶ Requires sh_admin_session             │
│   ├─ POST /admin/api/tables/:code/close                                      │
│   └─ POST /admin/api/tables/:code/players/:playerId/kick                     │
└────────┬─────────────────────────────────────────────────────────────────────┘
         │ authenticated JSON (3s auto-refresh + actions)
         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│ Admin Dashboard UI (/dashboard) & Shared Admin Top Bar                       │
│   ├─ KPI Strip (Tables, Active Games, Connected Players, TV Hosts)           │
│   ├─ Search & Status Filter Bar + Live Refresh Controls                      │
│   ├─ Table Cards (Room metadata, TV Hosts, Players + Device/Raw UA drawer)   │
│   └─ Inline Confirmation Flow for Kick Player & Close Table                  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Device Profile (`device` object stored per socket / player)**:
  - `category`: `'mobile' | 'tablet' | 'tv' | 'desktop' | 'bot' | 'unknown'`
  - `label`: Human-readable summary (e.g., `iPhone`, `Pixel / Android Phone`, `Android TV`, `Mac · Desktop`)
  - `os`: OS name and version when present (e.g., `iOS 18.1`, `Android 14`, `macOS`, `Windows`)
  - `browser`: Browser or WebView runtime (e.g., `Safari`, `Chrome`, `Firefox`, `Android WebView`)
  - `raw`: Exact raw `User-Agent` string (captured on WebSocket upgrade; updated if the player reconnects from a new device)
- **Live Table Snapshot (`GET /admin/api/tables` response)**:
  - `summary`: `{ tableCount, activeGameCount, lobbyCount, humanPlayerCount, connectedPlayerCount, botCount, hostDisplayCount, observerCount }`
  - `tables[]`:
    - `code`, `createdAt`, `lastActivity`, `idleMs`, `language`
    - `status`: `'in_game' | 'voting' | 'lobby'`
    - `game`: `{ type, label, phase, round }` (when running)
    - `hosts[]`: `{ socketCount, device, connectedAt }` (each connected `/ws/host/:code` display)
    - `players[]`: `{ playerId, username, avatar, isAdmin, connected, ready, sessionScore, lastSeen, device }`
    - `bots[]`: `{ playerId, username, avatar }`
    - `observers[]`: `{ observerId, username, connected, lastSeen, device }`
  - `generatedAt`: Server timestamp for sync accuracy.

### Interactive Component & State Mapping

- **Auth Gate**: Server checks `getAdminSession(req)` on `GET /dashboard`; missing session redirects to `/admin/login?next=%2Fdashboard` (or renders the OIDC setup prompt if OIDC is unconfigured). Client API wrapper redirects to `/admin/login?next=%2Fdashboard` on `401`.
- **Filter & Search State**: Client holds `{ query, statusFilter, autoRefresh, expandedUaIds }` across polling cycles so expanding a player's raw `User-Agent` or typing a filter query is never wiped out by a 3-second refresh.
- **Moderation Actions**:
  - *Kick Player*: Opens confirmation prompt → `POST /admin/api/tables/:code/players/:playerId/kick` → server notifies socket, closes WS, clears grace timer, calls `room.removePlayer`, handles empty-human game stop if needed, and broadcasts `LOBBY_UPDATE` → dashboard immediately re-fetches `/admin/api/tables`.
  - *Close Table*: Opens confirmation prompt → `POST /admin/api/tables/:code/close` → server cancels all room timers (phase, bot, countdown, grace), broadcasts room closure to connected sockets and closes them, removes room from `RoomManager` → dashboard immediately re-fetches `/admin/api/tables`.

### Key Sequences & Integrations

- **OIDC Login with Return Destination**:
  - `GET /dashboard` (unauthenticated) → `302 /admin/login?next=%2Fdashboard` → `buildLoginRedirect` validates `next` (must start with `/` and not `//`) and embeds `returnTo` in signed `sh_oidc_tx` cookie → IdP authenticates → `GET /admin/callback` exchanges code + PKCE verifier, sets `sh_admin_session`, and redirects to `tx.returnTo || '/admin'`.
- **Shared Top Navigation**:
  - Both `/dashboard` and `/admin` share the exact same 3-zone header layout, linking between `Live Tables` (`/dashboard`) and `API & Games` (`/admin`), plus `Sign out` (`POST /admin/logout`).
